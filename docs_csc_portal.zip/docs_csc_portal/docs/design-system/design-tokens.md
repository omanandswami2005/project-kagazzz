# DocVault — Design Tokens

> A comprehensive design token reference for DocVault's visual language. All values defined here are the **single source of truth** for colors, typography, spacing, elevation, motion, and accessibility across platforms.

---

## Table of Contents

- [Color Palette](#color-palette)
- [Typography](#typography)
- [Spacing](#spacing)
- [Border Radius](#border-radius)
- [Shadows / Elevation](#shadows--elevation)
- [Motion / Animation](#motion--animation)
- [Breakpoints](#breakpoints)
- [Iconography](#iconography)
- [Accessibility](#accessibility)

---

## Color Palette

### Brand Colors

| Token | Hex | RGB | Purpose |
|---|---|---|---|
| `--color-primary` | `#1E3A5F` | `30, 58, 95` | Trust, Security — primary actions, headers, navigation |
| `--color-primary-light` | `#2D5486` | `45, 84, 134` | Primary hover states |
| `--color-primary-dark` | `#142842` | `20, 40, 66` | Primary active/pressed states |
| `--color-secondary` | `#F59E0B` | `245, 158, 11` | Accessibility, Warmth — highlights, CTAs, badges |
| `--color-secondary-light` | `#FBBF24` | `251, 191, 36` | Secondary hover states |
| `--color-secondary-dark` | `#D97706` | `217, 119, 6` | Secondary active/pressed states |

### Semantic Colors

| Token | Hex | Purpose | Usage |
|---|---|---|---|
| `--color-accent` | `#10B981` | Success, Growth | Confirmations, uploads complete, active states |
| `--color-accent-light` | `#34D399` | Success hover | Lighter success backgrounds |
| `--color-danger` | `#F43F5E` | Destructive actions | Delete, remove, error states |
| `--color-danger-light` | `#FB7185` | Danger hover | Error backgrounds, soft alerts |
| `--color-warning` | `#FB923C` | Caution | Expiring documents, quota warnings |
| `--color-warning-light` | `#FDBA74` | Warning hover | Warning backgrounds |
| `--color-info` | `#0EA5E9` | Informational | Tips, AI suggestions, help text |
| `--color-info-light` | `#38BDF8` | Info hover | Info backgrounds |

### Surface Colors

```mermaid
graph LR
    subgraph Light Mode
        L1["Surface 1<br/>#F8FAFC"] --> L2["Surface 2<br/>#F1F5F9"] --> L3["Surface 3<br/>#E2E8F0"]
    end
    subgraph Dark Mode
        D1["Surface 1<br/>#0F172A"] --> D2["Surface 2<br/>#1E293B"] --> D3["Surface 3<br/>#334155"]
    end
    style L1 fill:#F8FAFC,color:#0F172A
    style L2 fill:#F1F5F9,color:#0F172A
    style L3 fill:#E2E8F0,color:#0F172A
    style D1 fill:#0F172A,color:#F8FAFC
    style D2 fill:#1E293B,color:#F8FAFC
    style D3 fill:#334155,color:#F8FAFC
```

| Token | Light Mode | Dark Mode | Usage |
|---|---|---|---|
| `--surface-1` | `#F8FAFC` | `#0F172A` | Page background |
| `--surface-2` | `#F1F5F9` | `#1E293B` | Card backgrounds, panels |
| `--surface-3` | `#E2E8F0` | `#334155` | Elevated cards, modals, dropdowns |
| `--surface-inverse` | `#0F172A` | `#F8FAFC` | Inverted containers (tooltips, toasts) |

### Text Colors

| Token | Light Mode | Dark Mode | Usage |
|---|---|---|---|
| `--text-primary` | `#0F172A` | `#F8FAFC` | Headings, body text, primary labels |
| `--text-secondary` | `#475569` | `#CBD5E1` | Descriptions, captions, metadata |
| `--text-muted` | `#94A3B8` | `#64748B` | Placeholders, disabled text, hints |
| `--text-on-primary` | `#FFFFFF` | `#FFFFFF` | Text on primary-colored backgrounds |
| `--text-on-secondary` | `#0F172A` | `#0F172A` | Text on secondary-colored backgrounds |

### Border Colors

| Token | Light Mode | Dark Mode |
|---|---|---|
| `--border-default` | `#E2E8F0` | `#334155` |
| `--border-strong` | `#CBD5E1` | `#475569` |
| `--border-focus` | `#1E3A5F` | `#60A5FA` |

---

## Typography

### Font Families

| Token | Value | Usage |
|---|---|---|
| `--font-primary` | `'Inter', system-ui, -apple-system, sans-serif` | All Latin-script UI text |
| `--font-regional` | `'Noto Sans Devanagari', 'Noto Sans', sans-serif` | Hindi and regional language text |
| `--font-mono` | `'JetBrains Mono', 'Fira Code', monospace` | Code, document IDs, file sizes |

### Font Loading Strategy

```
1. Inter          → Google Fonts CDN, subset latin + latin-ext
2. Noto Sans Dev. → Google Fonts CDN, subset devanagari
3. system-ui      → OS fallback (always available)
```

> **Recommendation:** Use `font-display: swap` for all web fonts to prevent FOIT (Flash of Invisible Text).

### Type Scale

| Token | Size (px) | Size (rem) | Line Height | Usage |
|---|---|---|---|---|
| `--text-xs` | 12 | 0.75 | 1.33 (16px) | Badges, fine print, timestamps |
| `--text-sm` | 14 | 0.875 | 1.43 (20px) | Captions, helper text, metadata |
| `--text-base` | 16 | 1.0 | 1.5 (24px) | Body text, input fields, buttons |
| `--text-lg` | 18 | 1.125 | 1.56 (28px) | Subtitles, card titles |
| `--text-xl` | 20 | 1.25 | 1.4 (28px) | Section headings |
| `--text-2xl` | 24 | 1.5 | 1.33 (32px) | Page titles |
| `--text-3xl` | 30 | 1.875 | 1.27 (38px) | Hero text, large headings |
| `--text-4xl` | 36 | 2.25 | 1.22 (44px) | Display text, splash screens |

### Font Weights

| Token | Value | Usage |
|---|---|---|
| `--font-regular` | 400 | Body text, descriptions |
| `--font-medium` | 500 | Labels, navigation items, input values |
| `--font-semibold` | 600 | Card titles, section headings, buttons |
| `--font-bold` | 700 | Page titles, emphasis, stats values |

### Letter Spacing

| Token | Value | Usage |
|---|---|---|
| `--tracking-tight` | `-0.025em` | Large headings (2xl+) |
| `--tracking-normal` | `0` | Body text |
| `--tracking-wide` | `0.025em` | Uppercase labels, badges |

---

## Spacing

All spacing values are based on a **4px base grid** to ensure consistent rhythm across the interface.

| Token | Value (px) | Value (rem) | Usage |
|---|---|---|---|
| `--space-1` | 4 | 0.25 | Inline icon gaps, tight padding |
| `--space-2` | 8 | 0.5 | Icon-to-text gaps, compact padding |
| `--space-3` | 12 | 0.75 | Input padding, small card padding |
| `--space-4` | 16 | 1.0 | Standard padding, list item spacing |
| `--space-5` | 20 | 1.25 | Button padding, medium gaps |
| `--space-6` | 24 | 1.5 | Card padding, section gaps |
| `--space-8` | 32 | 2.0 | Large section gaps, modal padding |
| `--space-10` | 40 | 2.5 | Page top/bottom padding |
| `--space-12` | 48 | 3.0 | Section separators |
| `--space-16` | 64 | 4.0 | Page-level vertical spacing |
| `--space-20` | 80 | 5.0 | Hero sections, large separators |

### Spacing Guidelines

```
┌──────────────────────────────────────────────┐
│ Page Padding: space-4 (16px) mobile          │
│                space-8 (32px) desktop         │
│  ┌────────────────────────────────────────┐  │
│  │ Card Padding: space-4 to space-6       │  │
│  │  ┌──────────────────────────────────┐  │  │
│  │  │ Input Padding: space-3 (12px)    │  │  │
│  │  └──────────────────────────────────┘  │  │
│  │  gap between elements: space-2 (8px)   │  │
│  └────────────────────────────────────────┘  │
│  gap between cards: space-4 (16px)           │
└──────────────────────────────────────────────┘
```

---

## Border Radius

| Token | Value (px) | Usage |
|---|---|---|
| `--radius-sm` | 4 | Tags, badges, small chips |
| `--radius-md` | 8 | Buttons, inputs, cards |
| `--radius-lg` | 12 | Modals, panels, large cards |
| `--radius-xl` | 16 | Sheets, drawers, image containers |
| `--radius-2xl` | 24 | Floating action buttons, pills |
| `--radius-full` | 9999 | Avatars, circular buttons, toggles |

---

## Shadows / Elevation

DocVault uses a 5-level elevation system. Higher levels indicate greater visual prominence and interactivity.

| Token | Level | CSS Value | Usage |
|---|---|---|---|
| `--shadow-xs` | 1 | `0 1px 2px 0 rgba(0,0,0,0.05)` | Cards at rest, subtle separators |
| `--shadow-sm` | 2 | `0 1px 3px 0 rgba(0,0,0,0.1), 0 1px 2px -1px rgba(0,0,0,0.1)` | Hovered cards, raised inputs |
| `--shadow-md` | 3 | `0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1)` | Dropdowns, popovers, FABs |
| `--shadow-lg` | 4 | `0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1)` | Modals, side panels, sheets |
| `--shadow-xl` | 5 | `0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1)` | Full-screen overlays, toasts |

```mermaid
graph TB
    subgraph Elevation Hierarchy
        E1["Level 1 — shadow-xs<br/>Cards, list items"]
        E2["Level 2 — shadow-sm<br/>Hovered elements"]
        E3["Level 3 — shadow-md<br/>Dropdowns, FABs"]
        E4["Level 4 — shadow-lg<br/>Modals, drawers"]
        E5["Level 5 — shadow-xl<br/>Toasts, overlays"]
    end
    E1 --> E2 --> E3 --> E4 --> E5
```

### Dark Mode Shadows

In dark mode, shadows are less visible. Supplement with:
- Subtle **border** (`1px solid --border-default`)
- Slight **background lightening** (use `--surface-3`)
- Reduced shadow opacity (multiply by `0.5`)

---

## Motion / Animation

### Duration Tokens

| Token | Value | Usage |
|---|---|---|
| `--duration-instant` | `100ms` | Micro-interactions: checkbox toggle, icon color change |
| `--duration-fast` | `200ms` | Hover effects, button press feedback, tooltips |
| `--duration-normal` | `300ms` | Panel slides, card transitions, page fades |
| `--duration-slow` | `500ms` | Full-page transitions, complex animations, sheets |

### Easing Functions

| Token | Value | Usage |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | Elements entering the screen — decelerate into rest |
| `--ease-in` | `cubic-bezier(0.55, 0, 1, 0.45)` | Elements leaving the screen — accelerate out |
| `--ease-in-out` | `cubic-bezier(0.45, 0, 0.55, 1)` | Elements transitioning in place (expand/collapse) |
| `--ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Playful bouncy effects — FAB press, toggle switch |

### Animation Guidelines

```mermaid
flowchart LR
    A["User Action"] --> B{"Element<br/>Entering?"}
    B -->|Yes| C["ease-out<br/>+ duration-normal"]
    B -->|No| D{"Element<br/>Leaving?"}
    D -->|Yes| E["ease-in<br/>+ duration-fast"]
    D -->|No| F["ease-in-out<br/>+ duration-normal"]
```

**Principles:**
1. **Respect reduced-motion preferences:** Wrap all animations with `@media (prefers-reduced-motion: reduce)` and fall back to instant transitions.
2. **Performance:** Only animate `transform` and `opacity`. Avoid animating `width`, `height`, `top`, `left`.
3. **Intentional motion:** Every animation must have a purpose — guide attention, provide feedback, or establish spatial relationships.

---

## Breakpoints

DocVault uses a **mobile-first** responsive design system.

| Token | Min Width (px) | Target Devices |
|---|---|---|
| *(default)* | 0 | Small phones (portrait) |
| `--bp-sm` | 640 | Large phones (landscape), small tablets |
| `--bp-md` | 768 | Tablets (portrait) |
| `--bp-lg` | 1024 | Tablets (landscape), small laptops |
| `--bp-xl` | 1280 | Desktops, large laptops |

### Layout Behavior by Breakpoint

| Feature | < sm | sm – md | md – lg | lg+ |
|---|---|---|---|---|
| Navigation | Bottom tab bar | Bottom tab bar | Side drawer | Permanent sidebar |
| Document grid | 2 columns | 3 columns | 4 columns | 5–6 columns |
| Chat panel | Full screen | Full screen | Side panel (40%) | Side panel (30%) |
| Document preview | Full screen overlay | Full screen overlay | Split view | Split view |
| Page padding | 16px | 16px | 24px | 32px |

### Media Query Usage (CSS)

```css
/* Mobile first — default styles target smallest screens */
.container { padding: var(--space-4); }

@media (min-width: 640px)  { /* sm  */ }
@media (min-width: 768px)  { /* md  */ }
@media (min-width: 1024px) { /* lg  */ }
@media (min-width: 1280px) { /* xl  */ }
```

---

## Iconography

### Recommended Icon Library

| Library | Usage | Reason |
|---|---|---|
| **Lucide React** (primary) | All UI icons | Tree-shakeable, 1000+ icons, consistent 24px grid, MIT license, React-native integration |
| **Heroicons** (fallback) | Alternative when Lucide lacks an icon | By Tailwind team, same design philosophy |

### Icon Sizing

| Token | Size (px) | Usage |
|---|---|---|
| `--icon-xs` | 16 | Inline with small text, badges |
| `--icon-sm` | 20 | Inline with body text, list items |
| `--icon-md` | 24 | Buttons, navigation, cards (default) |
| `--icon-lg` | 32 | Empty states, section headers |
| `--icon-xl` | 48 | Onboarding illustrations, feature highlights |

### Icon Guidelines

- **Stroke width:** 1.5px (matches Lucide defaults)
- **Color:** Inherit from parent text color via `currentColor`
- **Touch targets:** Icons in interactive elements must have minimum **48×48px** touch target (use padding)
- **Accessibility:** Always pair icons with `aria-label` or visible text

---

## Accessibility

### Color Contrast Requirements (WCAG 2.1 AA)

| Text Type | Minimum Ratio | Verification |
|---|---|---|
| Normal text (< 18px) | **4.5:1** | Primary text on all surfaces ✅ |
| Large text (≥ 18px bold or ≥ 24px) | **3:1** | Headings on all surfaces ✅ |
| UI components & graphical objects | **3:1** | Icons, borders, form controls ✅ |

#### Contrast Validation Matrix

| Foreground | Background | Ratio | Pass? |
|---|---|---|---|
| `#0F172A` (text-primary) | `#F8FAFC` (surface-1) | **15.4:1** | ✅ AAA |
| `#475569` (text-secondary) | `#F8FAFC` (surface-1) | **7.1:1** | ✅ AA |
| `#94A3B8` (text-muted) | `#F8FAFC` (surface-1) | **3.3:1** | ✅ Large text only |
| `#FFFFFF` (text-on-primary) | `#1E3A5F` (primary) | **9.8:1** | ✅ AAA |
| `#F8FAFC` (text-primary dark) | `#0F172A` (surface-1 dark) | **15.4:1** | ✅ AAA |
| `#CBD5E1` (text-secondary dark) | `#0F172A` (surface-1 dark) | **9.5:1** | ✅ AAA |

### Touch Target Sizes

| Element | Minimum Size | Recommended Size |
|---|---|---|
| Buttons | 48 × 48 px | 48 × 48 px |
| Icon buttons | 48 × 48 px (including padding) | 48 × 48 px |
| List items | 48px height | 56px height |
| Checkboxes / Radios | 48 × 48 px (including padding) | 48 × 48 px |
| Links (inline) | 48px vertical padding zone | — |

### Focus Indicators

```css
/* Default focus ring — visible on all interactive elements */
:focus-visible {
  outline: 2px solid var(--color-primary);       /* Light mode */
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}

/* Dark mode focus ring */
@media (prefers-color-scheme: dark) {
  :focus-visible {
    outline-color: #60A5FA;  /* Brighter blue for dark backgrounds */
  }
}

/* NEVER use outline: none without a replacement */
```

### Screen Reader Support Patterns

| Pattern | Implementation |
|---|---|
| **Live regions** | `aria-live="polite"` for AI chat responses, upload progress |
| **Landmarks** | `<nav>`, `<main>`, `<aside>` for major page regions |
| **Labels** | All form inputs have associated `<label>` or `aria-label` |
| **Announcements** | Use `aria-live="assertive"` for errors, `polite` for success messages |
| **Hidden decorative elements** | `aria-hidden="true"` on purely decorative icons and images |
| **Document cards** | Use `role="article"` with `aria-labelledby` pointing to document name |
| **Modals** | Trap focus within modal, return focus on close, use `role="dialog"` |
| **Loading states** | `aria-busy="true"` on containers, `role="progressbar"` on loaders |

### Keyboard Navigation

| Key | Action |
|---|---|
| `Tab` / `Shift+Tab` | Move between interactive elements |
| `Enter` / `Space` | Activate buttons, links, toggles |
| `Escape` | Close modals, drawers, dropdowns |
| `Arrow keys` | Navigate within lists, grids, radio groups |
| `Home` / `End` | Jump to first/last item in lists |

---

## Token Implementation Reference

### CSS Custom Properties (Recommended)

```css
:root {
  /* Colors */
  --color-primary: #1E3A5F;
  --color-secondary: #F59E0B;
  --color-accent: #10B981;
  --color-danger: #F43F5E;
  --color-warning: #FB923C;
  --color-info: #0EA5E9;

  /* Surfaces — Light mode */
  --surface-1: #F8FAFC;
  --surface-2: #F1F5F9;
  --surface-3: #E2E8F0;

  /* Text — Light mode */
  --text-primary: #0F172A;
  --text-secondary: #475569;
  --text-muted: #94A3B8;

  /* Typography */
  --font-primary: 'Inter', system-ui, -apple-system, sans-serif;
  --font-regional: 'Noto Sans Devanagari', 'Noto Sans', sans-serif;

  /* Spacing (base: 4px) */
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-3: 0.75rem;
  --space-4: 1rem;
  --space-5: 1.25rem;
  --space-6: 1.5rem;
  --space-8: 2rem;
  --space-10: 2.5rem;
  --space-12: 3rem;
  --space-16: 4rem;
  --space-20: 5rem;

  /* Border Radius */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-2xl: 24px;
  --radius-full: 9999px;

  /* Motion */
  --duration-instant: 100ms;
  --duration-fast: 200ms;
  --duration-normal: 300ms;
  --duration-slow: 500ms;
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* Dark mode overrides */
[data-theme="dark"] {
  --surface-1: #0F172A;
  --surface-2: #1E293B;
  --surface-3: #334155;
  --text-primary: #F8FAFC;
  --text-secondary: #CBD5E1;
  --text-muted: #64748B;
  --border-default: #334155;
  --border-strong: #475569;
}
```

---

*Last updated: 2026-06-07 · DocVault Design System v1.0*
