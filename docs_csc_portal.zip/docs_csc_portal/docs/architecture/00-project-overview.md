# DocVault — Smart Document & Services Hub

> **Project Overview** · Version 1.0 · Last Updated: 2026-06-07

---

## Table of Contents

- [Vision](#vision)
- [Business Model: "Fear is Our Strategy"](#business-model-fear-is-our-strategy)
- [Version Roadmap](#version-roadmap)
  - [V1: Document Vault (Fully Offline)](#v1-document-vault-fully-offline)
  - [V2: Cloud & Sharing](#v2-cloud--sharing)
  - [V3: CSC Services Portal](#v3-csc-services-portal)
- [Version Progression Diagram](#version-progression-diagram)
- [Tech Stack Summary](#tech-stack-summary)
- [Target Users](#target-users)
- [Success Metrics](#success-metrics)

---

## Vision

> An all-in-one document management and government services app for India's **1.4 billion** citizens.

DocVault starts with **personal document organization** and **AI-powered document operations**, scales to **cloud-shared documents**, and ultimately becomes a **digital CSC (Common Service Centre)** — bringing **800+ government services** to every smartphone.

```mermaid
graph LR
    A["📱 Personal Vault<br/>(Offline-First)"] --> B["☁️ Cloud & Sharing<br/>(Connected)"]
    B --> C["🏛️ CSC Portal<br/>(Full Services)"]
    
    style A fill:#10b981,stroke:#064e3b,color:#fff
    style B fill:#3b82f6,stroke:#1e3a5f,color:#fff
    style C fill:#8b5cf6,stroke:#4c1d95,color:#fff
```

**Core Principle**: Every feature works offline first. Cloud is an enhancement, never a requirement. No user should be excluded because of connectivity.

---

## Business Model: "Fear is Our Strategy"

DocVault is built on a fundamental human truth — **people act on fear faster than on convenience**. Our four fear pillars drive user acquisition and retention:

| Fear Pillar | User Pain Point | DocVault Solution |
|---|---|---|
| 🔒 **Fear of Losing Documents** | Aadhaar, PAN, marksheets, certificates can be lost, damaged, or stolen | Secure on-device vault with biometric lock, encrypted backup, organized storage |
| ⏰ **Fear of Missing Deadlines** | Scholarship forms, exam registrations, government scheme deadlines slip by | Smart notifications, deadline tracking, auto-reminders for renewals |
| 😰 **Fear of Complex Processes** | Which forms? Which documents? What steps? Government processes are opaque | AI-guided workflows, step-by-step assistance, auto-fill from stored documents |
| 🛡️ **Fear of Getting Scammed** | Local CSC shops overcharge, steal data, or provide incomplete services | Transparent fee comparison, secure processing, verified service providers |

> **DocVault turns fear into trust** — secure, transparent, AI-guided, always accessible.

### Revenue Model (Planned)

| Tier | Price | Features |
|---|---|---|
| **Free** | ₹0 | Unlimited local storage, AI assistant (basic), all document operations |
| **Pro** | ₹99/month | Cloud backup, sharing, cross-device sync, priority AI |
| **CSC Operator** | ₹499/month | Full CSC portal, bulk processing, customer management, analytics |
| **Enterprise/Gov** | Custom | White-label, API access, government integrations |

---

## Version Roadmap

### V1: Document Vault (Fully Offline)

> **Status**: Active Development · **Target**: MVP Launch  
> **Core Promise**: "Your documents, always safe, always accessible — no internet needed."

#### Feature Set

| Category | Features |
|---|---|
| **Document Capture** | Upload from gallery, camera capture, file picker, document scanning with edge detection |
| **AI Document Operations** | Merge PDFs, split PDFs, convert formats (image↔PDF), compress files, encrypt/decrypt, OCR text extraction |
| **AI Chatbot** | Tool-calling capable LLM, can perform all document operations via natural conversation |
| **Voice Interface** | Offline Speech-to-Text (STT) and Text-to-Speech (TTS), full voice-driven document management |
| **Smart Navigation** | AI can navigate app screens automatically for user convenience |
| **Multilingual** | Hindi, English, + regional languages (Tamil, Telugu, Bengali, Marathi, and more) |
| **Smart Search** | Full-text search across document names, descriptions, OCR text, and tags |
| **Organization** | Nested folders, custom tags, categories, favorites, recent documents |
| **Security** | Biometric lock (fingerprint/face) for sensitive documents, per-document locking |
| **Accessibility** | Screen reader support, high contrast mode, adjustable font scaling, haptic feedback |
| **Storage** | 100% offline, on-device storage, usage stats, cleanup suggestions |

#### Key Differentiators (V1)

- **Fully offline AI** — no server, no data leaves the device
- **Voice-first design** — critical for accessibility and rural users
- **AI tool calling** — say "merge my Aadhaar and PAN into one PDF" and it's done
- **Edge-detected scanning** — professional quality document scans from any camera

---

### V2: Cloud & Sharing

> **Status**: Planned · **Requires**: V1 stable  
> **Core Promise**: "Share any document with anyone, anywhere — securely and on your terms."

#### Feature Set

| Category | Features |
|---|---|
| **Shareable Links** | Generate expirable, TTL-based sharing links for any document |
| **5-Digit Code Sharing** | Simple unique code — anyone enters it on a web route to access shared docs |
| **Cloud Backup** | End-to-end encrypted backup to cloud storage |
| **Cross-Device Sync** | Seamless sync across phone, tablet, and web |
| **Consent Management** | Granular control over who can access, download, or view shared documents |
| **Voice AI (Upgraded)** | Voice-to-voice AI assistant with improved conversational abilities |
| **Expiry Notifications** | Alerts for documents nearing expiry (licenses, certificates, IDs) |

#### Sharing Flow

```mermaid
sequenceDiagram
    participant User as DocVault User
    participant App as DocVault App
    participant Cloud as Cloud Service
    participant Recipient as Recipient

    User->>App: Select documents to share
    App->>App: Generate unique 5-digit code
    App->>Cloud: Upload encrypted document bundle
    App->>User: Display code + shareable link
    User->>Recipient: Share code via any channel
    Recipient->>Cloud: Enter code on web route
    Cloud->>Cloud: Verify TTL & access limits
    Cloud->>Recipient: Serve documents (view/download)
    Cloud->>App: Notify user of access event
```

---

### V3: CSC Services Portal

> **Status**: Planned · **Requires**: V2 stable  
> **Core Promise**: "Every government service, in your pocket, in your language."

#### Feature Set

| Category | Features |
|---|---|
| **Guided Workflows** | Step-by-step guidance for PAN card, Aadhaar, Passport, Income Certificate, Caste Certificate, etc. |
| **AI Service Expert** | Chatbot knows all processes, required documents, fees, timelines, and common pitfalls |
| **Auto-Fill Forms** | Automatically populate government forms from stored documents using OCR data |
| **Application Tracking** | Track status of submitted applications in real-time |
| **CSC Locator** | Find nearest physical CSC centers with ratings, reviews, and fee comparison |
| **Fee Transparency** | Compare DocVault's fees with local CSC rates — show users how much they save |
| **Community Features** | User reviews, tips, success stories, help forums |

#### Service Categories

```
📋 Identity Documents      — Aadhaar, PAN Card, Voter ID, Passport
📚 Education               — Marksheets, Certificates, Scholarship Applications  
💰 Financial               — Income Certificate, Tax Filing, Bank Account Opening
🏠 Property                — Land Records, Property Registration, Mutation
👨‍👩‍👧‍👦 Social Welfare          — Ration Card, Pension, Widow/Disability Benefits
🏥 Health                  — Ayushman Bharat, Health ID, Insurance Claims
💼 Employment              — PF, ESI, Labour Card, MSME Registration
🌾 Agriculture             — Kisan Credit Card, PM-KISAN, Crop Insurance
```

---

## Version Progression Diagram

```mermaid
graph TB
    subgraph V1["🟢 V1: Document Vault (Offline)"]
        V1A["📄 Document Upload/Capture/Scan"]
        V1B["🤖 AI Operations<br/>(merge, split, convert, compress, encrypt, OCR)"]
        V1C["💬 AI Chatbot + Tool Calling"]
        V1D["🎙️ Voice Input/Output (Offline)"]
        V1E["🔍 Smart Search + Filters + Tags"]
        V1F["🔐 Biometric Lock"]
        V1G["🌐 Multilingual Support"]
        V1H["♿ Full Accessibility"]
        V1I["🧭 AI Screen Navigation"]
    end

    subgraph V2["🔵 V2: Cloud & Sharing"]
        V2A["🔗 Shareable TTL Links"]
        V2B["🔢 5-Digit Code Sharing"]
        V2C["☁️ E2E Encrypted Cloud Backup"]
        V2D["🔄 Cross-Device Sync"]
        V2E["✅ Consent Management"]
        V2F["🎙️ Voice-to-Voice AI (Upgraded)"]
        V2G["⏰ Document Expiry Notifications"]
    end

    subgraph V3["🟣 V3: CSC Services Portal"]
        V3A["📝 Guided Service Workflows"]
        V3B["🤖 AI Service Expert"]
        V3C["📋 Auto-Fill Government Forms"]
        V3D["📊 Application Status Tracking"]
        V3E["📍 Nearest CSC Locator + Ratings"]
        V3F["💰 Fee Transparency"]
        V3G["👥 Community Features"]
    end

    V1 -->|"+ Cloud Layer"| V2
    V2 -->|"+ Services Layer"| V3

    style V1 fill:#ecfdf5,stroke:#10b981,stroke-width:2px
    style V2 fill:#eff6ff,stroke:#3b82f6,stroke-width:2px
    style V3 fill:#f5f3ff,stroke:#8b5cf6,stroke-width:2px
```

---

## Tech Stack Summary

### Frontend & UI

| Technology | Purpose | Version |
|---|---|---|
| **React** | UI library | 18.x+ |
| **TypeScript** | Type safety | 5.x+ |
| **Ionic Framework** | Mobile-optimized UI components | 8.x+ |
| **Tailwind CSS** | Utility-first styling | 3.x+ |
| **Vite** | Build tool & dev server | 5.x+ |

### State Management & Data Fetching

| Technology | Purpose |
|---|---|
| **Zustand** | Lightweight global state management |
| **TanStack Query** | Async data fetching, caching, and synchronization |
| **React Router v7+** or **Ionic React Router** | Client-side routing |

### Platform & Native

| Technology | Purpose |
|---|---|
| **Capacitor** | Native bridge for iOS, Android, and Web |
| **@capacitor-mlkit/document-scanner** | ML-powered document scanning with edge detection |
| **Native Capacitor STT/TTS Plugins** | Offline speech-to-text and text-to-speech |

### Document Processing

| Technology | Purpose |
|---|---|
| **pdf-lib** | PDF creation, modification, merging, splitting |
| **pdfjs-dist** | PDF rendering and text extraction |
| **@pdfsmaller/pdf-encrypt** | PDF encryption and password protection |
| **browser-image-compression** | Client-side image compression |
| **heic-to** | HEIC to JPEG/PNG conversion |
| **Canvas API** | Image manipulation, cropping, enhancement |

### AI & ML

| Technology | Purpose |
|---|---|
| **WebLLM (@mlc-ai/web-llm)** | On-device LLM inference for AI chatbot |
| **Transformers.js** | On-device ML models for document classification |
| **tesseract.js** | Client-side OCR text extraction |

### Database & Storage

| Technology | Purpose |
|---|---|
| **SQLite (@capacitor-community/sqlite)** | Primary structured data storage (native) |
| **Dexie.js** | IndexedDB wrapper (web fallback) |
| **Capacitor Filesystem** | Document file storage |

### Tech Stack Architecture

```mermaid
graph TB
    subgraph UI["Presentation Layer"]
        React["React 18+"]
        Ionic["Ionic Framework"]
        Tailwind["Tailwind CSS"]
    end

    subgraph State["State Layer"]
        Zustand["Zustand"]
        TanStack["TanStack Query"]
        Router["React Router v7+"]
    end

    subgraph Processing["Processing Layer"]
        PDF["pdf-lib / pdfjs-dist"]
        Image["browser-image-compression"]
        AI["WebLLM + Transformers.js"]
        OCR["tesseract.js"]
    end

    subgraph Platform["Platform Layer"]
        Capacitor["Capacitor"]
        SQLite["SQLite"]
        FS["Filesystem API"]
        Scanner["ML Kit Scanner"]
        Voice["STT / TTS"]
    end

    subgraph Target["Target Platforms"]
        Android["Android"]
        iOS["iOS"]
        Web["Web (PWA)"]
    end

    UI --> State
    State --> Processing
    Processing --> Platform
    Platform --> Target

    style UI fill:#fef3c7,stroke:#f59e0b,stroke-width:2px
    style State fill:#dbeafe,stroke:#3b82f6,stroke-width:2px
    style Processing fill:#fce7f3,stroke:#ec4899,stroke-width:2px
    style Platform fill:#d1fae5,stroke:#10b981,stroke-width:2px
    style Target fill:#e0e7ff,stroke:#6366f1,stroke-width:2px
```

---

## Target Users

### Primary User Personas

```mermaid
graph LR
    subgraph Personas["DocVault Target Users"]
        direction TB
        S["🎓 Students"]
        W["💼 Working Professionals"]
        SC["👴 Senior Citizens"]
        R["🌾 Rural Citizens"]
        C["🏪 CSC Operators"]
    end

    S --- SD["Marksheets, Scholarships,<br/>ID Cards, Admit Cards"]
    W --- WD["Tax Docs, Certificates,<br/>Employment Papers, Contracts"]
    SC --- SCD["Pension Docs, Health Records,<br/>Life Certificates, Insurance"]
    R --- RD["Government Scheme Docs,<br/>Land Records, Ration Cards"]
    C --- CD["V3: Professional Use,<br/>Bulk Processing, Customer Mgmt"]

    style Personas fill:#f0fdf4,stroke:#22c55e,stroke-width:2px
```

| Persona | Age Range | Key Needs | Version |
|---|---|---|---|
| **🎓 Students** | 15–25 | Store marksheets, track scholarship deadlines, manage admission documents | V1 |
| **💼 Working Professionals** | 25–55 | Tax documents, professional certificates, employment papers, quick sharing | V1 + V2 |
| **👴 Senior Citizens** | 55+ | Pension documents, health records, life certificates — needs voice & accessibility | V1 |
| **🌾 Rural Citizens** | All ages | Government scheme documents, land records, ration cards — needs multilingual + voice | V1 + V3 |
| **🏪 CSC Operators** | 25–50 | Professional document processing, customer management, service workflows | V3 |

### User Journey

```mermaid
journey
    title DocVault User Journey
    section Discovery
      Sees ad about document safety: 3: User
      Downloads app from Play Store: 4: User
    section V1 - Document Vault
      Scans Aadhaar card: 5: User
      Uploads marksheets: 5: User
      Asks AI to merge PDFs: 5: User
      Uses voice to search docs: 4: User
    section V2 - Sharing
      Shares docs via 5-digit code: 5: User
      Enables cloud backup: 4: User
      Gets expiry notification: 5: User
    section V3 - Services
      Applies for PAN card via app: 5: User
      AI guides through process: 5: User
      Tracks application status: 4: User
```

---

## Success Metrics

| Metric | V1 Target | V2 Target | V3 Target |
|---|---|---|---|
| **Downloads** | 100K | 500K | 2M |
| **DAU** | 10K | 50K | 200K |
| **Retention (D30)** | 40% | 50% | 60% |
| **Documents Stored** | 500K | 5M | 50M |
| **AI Interactions/Day** | 5K | 25K | 100K |
| **NPS Score** | 50+ | 60+ | 70+ |
| **Services Processed** | — | — | 10K/month |
| **Revenue** | — | ₹5L/month | ₹50L/month |

---

> [!NOTE]
> This document serves as the north star for DocVault development. All architectural and design decisions should align with the vision outlined here. Each version builds on the previous one — **V1 must be rock-solid before V2 begins**.

---

*Document maintained by the DocVault Architecture Team*
